const API_BASE_URL = (
  import.meta.env.VITE_API_BASE_URL || "http://localhost:8000"
).replace(/\/$/, "");

async function request(path, options = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {})
    },
    ...options
  });

  const text = await response.text();
  let data = null;

  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = text;
  }

  if (!response.ok) {
    const message =
      typeof data === "object" && data?.detail
        ? data.detail
        : typeof data === "object" && data?.message
          ? data.message
          : text || `Request failed with status ${response.status}`;

    throw new Error(message);
  }

  return data;
}

/*
  Expected backend contract:

  GET  /api/branches?repository_url=<repo-url>
       -> { branches: [...] }

  POST /api/review/latest-commit
       body: { repository_url, branch_name, team_instruction? }
       -> {
            commit: {...},
            review: {...},
            team_memory: ...
          }

  If your backend uses different routes, change only these two functions.
*/

export async function getBranches(repositoryUrl) {
  const params = new URLSearchParams({
    repository_url: repositoryUrl
  });

  const data = await request(`/api/branches?${params.toString()}`);
  return data?.branches || data || [];
}

export async function reviewLatestCommit({
  repositoryUrl,
  branchName,
  teamInstruction
}) {
  return request("/api/review/latest-commit", {
    method: "POST",
    body: JSON.stringify({
      repository_url: repositoryUrl,
      branch_name: branchName,
      team_instruction: teamInstruction || ""
    })
  });
}